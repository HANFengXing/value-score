import copy
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from build_dataset import SCORER
from validate_dataset import validate, read_rows
from make_review_batch import export

class DatasetTests(unittest.TestCase):
    def record(self,kind='answer',levels=(3,3,3,4)):
        return {'kind':kind,'rubric_version':'1.1','dimensions':{
            name:{'status':'scored','level':level,'evidence':'Explicit test fixture','reason':'Next anchor not demonstrated'}
            for name,level in zip(SCORER.WEIGHTS[kind],levels)},'gates':[]}

    def test_full_dataset_integrity(self):
        report = validate()
        self.assertEqual(report['collections']['public']['rows'],1038)
        self.assertEqual(report['collections']['chinese']['rows'],64)
        self.assertEqual(report['judge_accuracy'],'not_measured')

    def test_half_up_rounding(self):
        self.assertEqual(SCORER.evaluate(self.record())['score'],79)
        self.assertEqual(SCORER.evaluate(self.record(levels=(4,3,4,4)))['score'],93)

    def test_unicode_line_separator_is_content_not_jsonl_delimiter(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'unicode.jsonl'
            path.write_text(json.dumps({'id':'unicode','answer':'before\u0085middle\u2028after'},ensure_ascii=False)+'\n',encoding='utf-8')
            self.assertEqual(len(read_rows(path)),1)

    def test_unknown_keeps_weight(self):
        record=self.record(levels=(4,4,4,4))
        record['dimensions']['alignment']={'status':'unknown','level':None,'reason':'No delivery evidence'}
        result=SCORER.evaluate(record)
        self.assertIsNone(result['score'])
        self.assertEqual(result['bounds'],[70,100])
        self.assertEqual(result['coverage_percent'],70)

    def test_na_and_unknown_are_distinct(self):
        record=self.record()
        record['dimensions']['efficiency']={'status':'na','level':None,'reason':'Synthetic arithmetic fixture only'}
        self.assertEqual(SCORER.evaluate(record)['score'],75)
        record['dimensions']['efficiency']['status']='unknown'
        self.assertEqual(SCORER.evaluate(record)['bounds'],[63,79])

    def test_caps_and_bad_levels(self):
        record=self.record(levels=(4,4,4,4))
        for gate,cap in [('confirmed_core_error',39),('fabricated_source',39),('false_completion',39),('off_topic',39),('promise_only',49)]:
            record['gates']=[{'type':gate,'evidence':'Confirmed fixture condition'}]
            self.assertEqual(SCORER.evaluate(record)['score'],cap)
        record['gates']=[]
        record['dimensions']['alignment']['level']=True
        with self.assertRaises(ValueError): SCORER.evaluate(record)
        record['dimensions']['alignment']['level']=5
        with self.assertRaises(ValueError): SCORER.evaluate(record)

    def test_blind_export_has_no_answers_in_questions_or_labels_in_inputs(self):
        with tempfile.TemporaryDirectory() as folder:
            export('chinese','holdout',Path(folder))
            for line in (Path(folder)/'questions.blind.jsonl').read_text(encoding='utf-8').splitlines():
                row=json.loads(line)
                self.assertEqual(set(row),{'group_id','context','question'})
            for line in (Path(folder)/'answers.blind.jsonl').read_text(encoding='utf-8').splitlines():
                row=json.loads(line)
                self.assertEqual(set(row),{'id','group_id','context','question','answer'})
            templates=[json.loads(x) for x in (Path(folder)/'annotations.template.jsonl').read_text(encoding='utf-8').splitlines()]
            self.assertTrue(all(x['question_record'] is None and x['answer_record'] is None for x in templates))

if __name__=='__main__':
    unittest.main()
