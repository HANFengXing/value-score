# 字段与评分

## 输入 JSONL

每行包含 `id`、`group_id`、`split`、`language`、`origin`、`context`、`question`、`answer`。

公开输入另有 source（原数据集、固定提交、原始行号、许可证）。中文输入另有 tags、reference、leakage_group。reference是构造题目的核验依据，盲评导出时会移除。

## 公开标签

每行通过id与输入关联。原始五轴标签不变；`composite_value_score=null` 表示没有转换为value-score总分。`independent_of_this_builder=true` 只表示上游人工标签独立于本次打包作者，不表示对任意待测模型完全独立。

## 中文标签

- `question_record`：kind=question；四维 importance/unknown/leverage/researchability。
- `answer_record`：kind=answer；四维 alignment/reliability/gain/efficiency。
- 每维：status=scored/unknown/na；scored时level为0–4整数，否则null。
- evidence：评分依据；reason：未达到下一等级、未知或不适用的具体理由。
- evidence_type、locator：观察/推断等证据类型与定位；不代表经过外部独立审查。
- gates：已确认的核心错误、虚构来源、虚假完成、偏题或只有承诺；附触发证据。
- question_result/answer_result：原skill脚本的计算结果摘要。
- score：只有所有适用维度均有证据时才为整数；否则null。
- bounds：未知维度导致的上下界；不是统计置信区间。
- coverage_percent：可评价维度权重占比，不是正确概率。
- cap：严重错误上限；没有上限时null。
- question_improvement/answer_improvement：下一项有收益的具体改进。

权重固定30/30/25/15；unknown不删除权重，na才移除。完整无未知时采用四舍五入、0.5向上；区间下界向下、上界向上取整。错误上限采用所有已触发上限中的最低值。

## 成对记录

answer_ids始终是同组两个id。preferred_id是较高自评分数的id、tie或unresolved。它们是同作者等级派生偏好，不是单独采集的人工偏好标签。AB/BA稳定性标为not_measured。

## 新增标注

先按上述字段记录等级与证据，再调用skill的score.py。该脚本验证计算，不验证证据真假。纯启停消息、致谢和工具输出不应纳入实质问答评分。
