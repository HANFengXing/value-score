"""Local advisory score predictions. Model estimates are not verified evidence."""
import argparse
import hashlib
import importlib.util
import json
import math
import re
from pathlib import Path

import numpy as np
from scipy.sparse import hstack
from sklearn.feature_extraction.text import TfidfVectorizer

SKILL = Path(__file__).resolve().parents[1]
DEFAULT_MODEL = SKILL / 'models/baseline-v1'
MAX_FIELD_CHARS = 12000
PERSONAL_WEIGHTS = (30, 30, 25, 15)


def read_jsonl(path):
    rows = [json.loads(line) for line in Path(path).read_text(encoding='utf-8-sig').split('\n') if line.strip()]
    ids = [r.get('id') for r in rows]
    if any(not isinstance(i, str) or not i for i in ids) or len(set(ids)) != len(ids):
        raise ValueError('JSONL requires nonempty unique string IDs')
    return rows


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def texts(rows, source):
    """Only context/question/answer enter features; never labels, refs, IDs or tags."""
    if source == 'question':
        return [(str(r.get('context', ''))[:MAX_FIELD_CHARS] + '\n' + str(r.get('question', ''))[:MAX_FIELD_CHARS]) for r in rows]
    if source == 'answer':
        return [str(r.get('answer', ''))[:MAX_FIELD_CHARS] for r in rows]
    raise ValueError('Unknown feature source')


def chinese_fraction(value):
    letters = [c for c in value if c.isalpha()]
    return sum('\u3400' <= c <= '\u9fff' for c in letters) / max(1, len(letters))


def route(row, kind='answer', collection='auto'):
    if kind not in ('question', 'answer') or collection not in ('auto', 'chinese', 'public'):
        raise ValueError('Invalid kind or collection')
    if collection == 'auto':
        collection = 'chinese' if chinese_fraction(row.get('question', '') + row.get('context', '')) >= .1 else 'public'
    if kind == 'question' and collection == 'public':
        return None
    return f'{collection}_{kind}'


def vectorizer(config, vocabulary=None):
    return TfidfVectorizer(analyzer=config['analyzer'], ngram_range=tuple(config['ngram_range']),
                           min_df=config['min_df'], max_features=config['max_features'],
                           sublinear_tf=True, lowercase=True, dtype=np.float64,
                           token_pattern=r'(?u)\b\w+\b' if config['analyzer'] == 'word' else None, vocabulary=vocabulary)


def fit_features(rows, configs):
    banks, matrices = [], []
    for config in configs:
        fitted = vectorizer(config)
        matrix = fitted.fit_transform(texts(rows, config['source']))
        banks.append((config, fitted))
        matrices.append(matrix)
    return banks, hstack(matrices, format='csr')


def transform_features(rows, banks):
    return hstack([fitted.transform(texts(rows, config['source'])) for config, fitted in banks], format='csr')


def official_scorer():
    spec = importlib.util.spec_from_file_location('evidence_scorer_runtime', SKILL / 'scripts/score.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ScoreModel:
    def __init__(self, directory=DEFAULT_MODEL):
        self.directory = Path(directory)
        self.manifest = json.loads((self.directory / 'model.json').read_text(encoding='utf-8'))
        if self.manifest.get('format_version') != 1:
            raise ValueError('Unsupported model format')
        # JSON and numerical arrays only: no pickle or executable model deserialization.
        for filename in ('vocabulary.json', 'weights.npz'):
            if sha256(self.directory / filename) != self.manifest['artifacts_sha256'][filename]:
                raise ValueError(f'Model artifact checksum mismatch: {filename}')
        vocabulary = json.loads((self.directory / 'vocabulary.json').read_text(encoding='utf-8'))
        with np.load(self.directory / 'weights.npz', allow_pickle=False) as archive:
            self.weights = {k: archive[k].copy() for k in archive.files}
        self.tasks = {}
        for task, metadata in self.manifest['tasks'].items():
            banks = []
            for i, config in enumerate(metadata['features']):
                vocab = vocabulary[f'{task}_{i}']
                fitted = vectorizer(config, vocab)
                fitted.vocabulary_ = vocab
                fitted.fixed_vocabulary_ = True
                fitted.idf_ = self.weights[f'{task}_idf_{i}']
                banks.append((config, fitted))
            self.tasks[task] = banks

    def predict_raw(self, task, rows):
        matrix = transform_features(rows, self.tasks[task])
        results = {}
        for name, head in self.manifest['tasks'][task]['heads'].items():
            key = f'{task}_{name}'
            value = np.asarray(matrix @ self.weights[key + '_coef']).reshape(-1) + float(self.weights[key + '_intercept'][0])
            results[name] = 1 / (1 + np.exp(-np.clip(value, -40, 40))) if head['type'] == 'binary_logistic' else np.clip(value, 0, 4)
        return results

    def predict(self, row, kind='answer', collection='auto', verified_record=None):
        if not isinstance(row.get('question'), str) or not row['question'].strip():
            raise ValueError('A nonempty question is required')
        if not isinstance(row.get('context', ''), str):
            raise ValueError('context must be text')
        if kind == 'answer' and (not isinstance(row.get('answer'), str) or not row['answer'].strip()):
            raise ValueError('A nonempty answer is required')
        task = route(row, kind, collection)
        names = official_scorer().WEIGHTS[kind]
        template = {'kind': kind, 'rubric_version': '1.1', 'dimensions': {
            name: {'status': 'unknown', 'level': None, 'evidence': '',
                   'reason': 'Model estimate awaits content/evidence review.'} for name in names}, 'gates': []}
        output = {'id': row.get('id'), 'model_id': self.manifest['model_id'], 'task': task,
                  'status': 'advisory_only', 'independent_review': False,
                  'dimension_predictions': {}, 'provisional_uncapped_index': None,
                  'review_template': template, 'warnings': [],
                  'verified_result': official_scorer().evaluate(template)}
        if task is None:
            output['status'] = 'unsupported'
            output['warnings'].append('Public human labels do not train personal question-value dimensions.')
        elif task == 'public_answer' and chinese_fraction(row.get('question', '') + row.get('answer', '')) >= .1:
            output['status'] = 'unsupported'
            output['warnings'].append('The public model was trained on English, not Chinese.')
        else:
            raw = self.predict_raw(task, [row])
            for name, values in raw.items():
                if name == 'cap_risk':
                    output['cap_review_signal'] = {'value': float(values[0]), 'threshold': .5,
                        'flag_for_review': bool(values[0] >= .5), 'calibrated_probability': False,
                        'confirmed_gate': None}
                    continue
                head = self.manifest['tasks'][task]['heads'][name]
                suggested = int(math.floor(float(values[0]) + .5))
                if task == 'chinese_question' and name in ('importance', 'leverage') and not row.get('context', '').strip():
                    suggested = None
                output['dimension_predictions'][name] = {'continuous': float(values[0]), 'suggested_level': suggested,
                    'label_source': self.manifest['tasks'][task]['label_source'],
                    'training_rows': head['training_rows'], 'training_unique_levels': head['unique_levels'],
                    'learned_constant': head['type'] == 'constant', 'verified': False}
                if name in template['dimensions']:
                    template['dimensions'][name]['suggested_level'] = suggested
            if task.startswith('chinese_'):
                levels = [output['dimension_predictions'][n]['suggested_level'] for n in names]
                if all(v is not None for v in levels):
                    output['provisional_uncapped_index'] = int(math.floor(sum(w * v / 4 for w, v in zip(PERSONAL_WEIGHTS, levels)) + .5))
                output['warnings'].append('Chinese labels are author self-annotations; this predicts their rubric, not independent human value.')
            else:
                output['warnings'].append('Public dimensions are not the personal value-score dimensions or its composite index.')
            output['warnings'].append('Predictions do not verify facts, task completion, unknown/NA states or serious-error gates.')
            if any(len(row.get(k, '')) > MAX_FIELD_CHARS for k in ('context', 'question', 'answer')):
                output['warnings'].append('Text fields were truncated to 12000 characters each, as during training.')
        if verified_record is not None:
            if verified_record.get('kind') != kind:
                raise ValueError('Verified record kind does not match request')
            output['verified_result'] = official_scorer().evaluate(verified_record)
            output['verification_source'] = 'caller_supplied_evidence_record; caller must verify evidence truth'
        return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path, help='JSON object with context/question/answer; or JSONL with --jsonl')
    parser.add_argument('--kind', choices=['answer', 'question'], default='answer')
    parser.add_argument('--collection', choices=['auto', 'public', 'chinese'], default='auto')
    parser.add_argument('--model-dir', type=Path, default=DEFAULT_MODEL)
    parser.add_argument('--verified-record', type=Path)
    parser.add_argument('--jsonl', action='store_true')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    model = ScoreModel(args.model_dir)
    review = json.loads(args.verified_record.read_text(encoding='utf-8-sig')) if args.verified_record else None
    if args.jsonl and review:
        raise ValueError('A single verified record cannot be applied to a batch')
    rows = read_jsonl(args.input) if args.jsonl else [json.loads(args.input.read_text(encoding='utf-8-sig'))]
    outputs = [model.predict(r, args.kind, args.collection, review) for r in rows]
    rendered = ''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in outputs) if args.jsonl else json.dumps(outputs[0], ensure_ascii=False, indent=2) + '\n'
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(rendered, encoding='utf-8')
    else:
        print(rendered)


if __name__ == '__main__':
    main()
