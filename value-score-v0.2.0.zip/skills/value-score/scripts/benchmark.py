"""Compare existing 0..4 predictions with external labels; no judge/model calls."""
import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

ATTRIBUTES = ('helpfulness', 'correctness', 'coherence')

def read_rows(path, prediction=False):
    rows = {}
    for line in Path(path).read_text(encoding='utf-8-sig').splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        item_id = row.get('id')
        if not isinstance(item_id, str) or not item_id or item_id in rows:
            raise ValueError('Missing or duplicate id')
        for attribute in ATTRIBUTES:
            value = row.get(attribute)
            if value is None and prediction:
                continue
            if type(value) is not int or not 0 <= value <= 4:
                raise ValueError(f'{item_id}/{attribute}: needs integer 0..4')
        rows[item_id] = row
    if not rows:
        raise ValueError('Empty file')
    return rows

def quadratic_kappa(pairs):
    n = len(pairs)
    if not n:
        return None
    observed = sum((a-b)**2 for a, b in pairs)/n
    ca, cb = Counter(a for a, _ in pairs), Counter(b for _, b in pairs)
    expected = sum(ca[a]*cb[b]*(a-b)**2 for a in ca for b in cb)/(n*n)
    return None if expected == 0 else 1-observed/expected

def compare(gold, predictions):
    if set(predictions)-set(gold):
        raise ValueError('Prediction contains ids absent from gold')
    results = {'human_rows': len(gold), 'prediction_rows': len(predictions),
               'missing_rows': len(set(gold)-set(predictions)), 'dimensions': {}}
    for attribute in ATTRIBUTES:
        pairs = [(row[attribute], predictions[i][attribute]) for i, row in gold.items()
                 if i in predictions and predictions[i].get(attribute) is not None]
        n = len(pairs)
        results['dimensions'][attribute] = {
            'n': n, 'coverage': n/len(gold),
            'mae': sum(abs(a-b) for a,b in pairs)/n if n else None,
            'exact_agreement': sum(a==b for a,b in pairs)/n if n else None,
            'within_one_level': sum(abs(a-b)<=1 for a,b in pairs)/n if n else None,
            'mean_signed_error_prediction_minus_human': sum(b-a for a,b in pairs)/n if n else None,
            'quadratic_weighted_kappa': quadratic_kappa(pairs),
            'human_distribution': dict(sorted(Counter(a for a,_ in pairs).items())),
            'prediction_distribution': dict(sorted(Counter(b for _,b in pairs).items())),
        }
    groups = defaultdict(list)
    for item_id, row in gold.items():
        if row.get('pair_id'):
            groups[row['pair_id']].append(item_id)
    direction = lambda a,b: (a>b)-(a<b)
    all_pairs, non_ties, details = [], [], []
    invalid_groups = 0
    for pair_id, ids in sorted(groups.items()):
        if len(ids) != 2:
            invalid_groups += 1
            continue
        a,b = sorted(ids)
        if any(i not in predictions or predictions[i].get('helpfulness') is None for i in (a,b)):
            continue
        expected = direction(gold[a]['helpfulness'], gold[b]['helpfulness'])
        predicted = direction(predictions[a]['helpfulness'], predictions[b]['helpfulness'])
        agrees = expected == predicted
        all_pairs.append(agrees)
        if expected:
            non_ties.append(agrees)
        details.append({'pair_id': pair_id, 'ids': [a,b], 'human_direction': expected,
                        'predicted_direction': predicted, 'agrees': agrees})
    results['derived_pairwise_helpfulness'] = {
        'label_source': 'Derived from scalar helpfulness; not separately collected preference labels',
        'n_complete_pairs': len(all_pairs), 'n_human_non_ties': len(non_ties),
        'n_human_ties': len(all_pairs)-len(non_ties), 'invalid_pair_groups': invalid_groups,
        'agreement_all_including_ties': sum(all_pairs)/len(all_pairs) if all_pairs else None,
        'agreement_on_human_non_ties': sum(non_ties)/len(non_ties) if non_ties else None,
        'details': details,
    }
    results['order_stability'] = 'not_measured: no independent AB/BA records supplied'
    results['warning'] = 'Agreement on matching dataset axes; not accuracy of the composite value index'
    return results

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('gold', type=Path)
    parser.add_argument('predictions', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    result = compare(read_rows(args.gold), read_rows(args.predictions, prediction=True))
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.write_text(rendered+'\n', encoding='utf-8')
    else:
        print(rendered)

if __name__ == '__main__':
    main()
