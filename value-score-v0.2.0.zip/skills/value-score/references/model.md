# 本地模型接入

技能1.2沿用量表1.1。模型`value-score-tfidf-ridge-v1`是本地CPU文本模型，不是大语言模型微调。

## 已训练的内容

- 英文回答：832条HelpSteer2原始人工标签训练，206条按问题隔离的留出回答评测；预测helpfulness/correctness/coherence。
- 中文回答：50条构造自评回答训练，14条按相关目标家族隔离的留出回答评测；预测alignment/reliability/gain/efficiency，以及需核验严重错误的信号。
- 中文问题：25个独立问题训练，7个留出问题评测；同一问题的两个回答不重复算训练问题。缺证据标签不当作0。
- 词表、IDF及正则化参数仅由训练部分学习；三折按组交叉验证选择参数。没有训练个人量表权重。

特征为TF-IDF词与字符片段，分维使用Ridge回归；严重错误复核信号使用逻辑回归。输入仅context/question/answer，参考答案、标签依据、案例ID、作者、来源、标签和顺序不进入特征。长字段截取前12000字符。词法模型容易学习写作习惯，无法核验事实。

## 调用

在技能目录下，将当前材料写入临时JSON，不建立长期日志：

```json
{"context":"学习 C++20 数组边界", "question":"vector<int> a(1000)，a[1000] 会怎样？", "answer":"越界是未定义行为，不保证崩溃；有效下标为0到999。"}
```

```powershell
python scripts/score.py input.json --predict --kind answer --out prediction.json
python scripts/score.py input.json --predict --kind question --out question-prediction.json
```

`dimension_predictions`是未核验的0–4级建议。中文`provisional_uncapped_index`只是建议等级按原权重计算的未应用错误上限的预评分，不是正式总分。模型并未学习判断unknown或NA；缺目标背景时问题importance/leverage不给建议等级。

`cap_review_signal`是作者错误标签上训练的未经概率校准的信号。即使它低于阈值，也不能证明没有错误；高于阈值也不能确认错误或自动套用39/49分上限。

`review_template`全部正式等级初始为unknown；`verified_result`初始显示待评范围0–100。先核验具体证据，再把适用维度填入正式等级、evidence与reason；确有错误时添加gates。原`score.py evaluation.json`仍按证据记录计算。也可将填好的记录传给模型入口：

```powershell
python scripts/model_runtime.py input.json --verified-record evaluation.json --out reviewed.json
```

外部英文维度不映射成个人价值总分。英文问题价值没有训练模型；调用时显示不支持。

## 当前效果及边界

英文留出集的MAE：helpfulness 1.058（常数基线1.015）、correctness 1.024（0.990）、coherence 0.345（0.350）。前两项未改善；第三项差异很小，不足以证明有用的泛化。

中文回答四维MAE平均0.897，常数基线1.195；只是对14条作者自评标签的拟合一致性，没有独立人工正确率。中文问题预测和常数基线相同，关键未知训练标签只有一个等级，低误差不能证明理解了问题价值。严重错误检测在小样本上仍有漏报。

完整报告、按组bootstrap区间、原始留出预测和划分审计位于分发包`reports/model/`。各维有效样本数可能因unknown标签减少。没有真实AB/BA复核。用户收益未实测。当前仅用于提示复核，正式评分仍由可检查证据决定。

## 模型格式与依赖

模型在`models/baseline-v1/`：JSON词表/元数据及`allow_pickle=False`加载的NPZ数值权重；入口检查文件SHA256。不使用pickle，不调用外部API。

已验证：Python3.11.7、numpy1.26.4、scipy1.11.4、scikit-learn1.2.2。独立环境用分发包`requirements-model.txt`安装。原有证据计分脚本不需要这些依赖。

重训从分发包根目录运行`python scripts/train_model.py`。保留现有留出划分；若已利用其效果反复改模型，该集合不再是新的独立验证，需新增独立问题/标签。
