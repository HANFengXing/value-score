"""Build pinned public data and constructed Chinese examples. No model calls."""
import argparse
import csv
import gzip
import hashlib
import importlib.util
import json
import urllib.request
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = '990b2711a36180dd19d9c94b8627844866f8982a'
SOURCE_URL = f'https://huggingface.co/datasets/nvidia/HelpSteer2/resolve/{REVISION}/validation.jsonl.gz'
SEED = '20261012'
ATTRIBUTES = ('helpfulness', 'correctness', 'coherence', 'complexity', 'verbosity')
SPEC = importlib.util.spec_from_file_location('value_score', ROOT / 'skills/value-score/scripts/score.py')
SCORER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SCORER)

def digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(''.join(json.dumps(x, ensure_ascii=False, separators=(',', ':')) + '\n' for x in rows), encoding='utf-8')

def split_groups(group_ids, weights=None):
    ordered = sorted(set(group_ids), key=lambda x: digest(SEED + ':' + x))
    weights = weights or {x: 1 for x in ordered}
    target = max(1, sum(weights[x] for x in ordered) // 5)
    holdout, count = set(), 0
    for group in ordered:
        if count >= target:
            break
        holdout.add(group)
        count += weights[group]
    return {x: ('holdout' if x in holdout else 'calibration') for x in ordered}

def dimension(item):
    if isinstance(item, dict):
        return {'status': item['status'], 'level': None, 'evidence': '',
                'reason': item['reason'], 'evidence_type': 'unverified', 'locator': 'context'}
    level, evidence, reason = item
    return {'status': 'scored', 'level': level, 'evidence': evidence, 'reason': reason,
            'evidence_type': 'observation', 'locator': 'question_and_context' if evidence.startswith('问题') else 'answer_or_supplied_reference'}

def evaluation(kind, items, gates=None):
    names = tuple(SCORER.WEIGHTS[kind])
    if len(items) != 4:
        raise ValueError('Expected exactly four dimensions')
    record = {'kind': kind, 'rubric_version': '1.1',
              'dimensions': dict(zip(names, map(dimension, items))), 'gates': gates or []}
    if kind == 'question':
        for name in ('importance', 'leverage'):
            if record['dimensions'][name]['status'] == 'scored':
                record['dimensions'][name]['evidence_type'] = 'inference'
    result = SCORER.evaluate(record)
    return record, {k: result[k] for k in ('status', 'score', 'bounds', 'coverage_percent', 'cap')}

def build_public(refresh=False):
    archive = ROOT / 'data/helpsteer2-validation.source.jsonl.gz'
    if refresh or not archive.exists():
        archive.parent.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(SOURCE_URL, timeout=45) as response:
            archive.write_bytes(response.read())
    raw = gzip.decompress(archive.read_bytes())
    source = [json.loads(line) for line in raw.splitlines() if line.strip()]
    groups = {r['prompt']: 'hs2-' + digest(r['prompt'])[:20] for r in source}
    splits = split_groups(groups.values())
    inputs, labels = [], []
    for index, row in enumerate(source):
        group_id = groups[row['prompt']]
        item_id = f'hs2-validation-{index:04d}'
        inputs.append({'id': item_id, 'group_id': group_id, 'split': splits[group_id],
                       'language': 'en', 'origin': 'public_helpsteer2', 'context': '',
                       'question': row['prompt'], 'answer': row['response'],
                       'source': {'dataset': 'nvidia/HelpSteer2', 'revision': REVISION,
                                  'upstream_split': 'validation', 'row_index': index,
                                  'license': 'CC-BY-4.0'}})
        labels.append({'id': item_id, 'group_id': group_id, 'split': splits[group_id],
                       'label_origin': 'upstream_human_annotation', 'independent_of_this_builder': True,
                       'composite_value_score': None, **{k: row[k] for k in ATTRIBUTES}})
    write_jsonl(ROOT / 'data/public/inputs.jsonl', inputs)
    write_jsonl(ROOT / 'data/public/labels.jsonl', labels)
    write_json(ROOT / 'data/public/provenance.json', {
        'creator': 'NVIDIA', 'dataset': 'nvidia/HelpSteer2', 'revision': REVISION,
        'retrieved_date': '2026-10-12', 'source_url': SOURCE_URL, 'upstream_split': 'validation',
        'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        'decompressed_sha256': hashlib.sha256(raw).hexdigest(), 'rows': len(source),
        'prompt_groups': len(groups), 'filter': 'none: complete upstream validation split',
        'modifications': 'Original prompt/response/labels preserved; stable IDs and group splits added.',
        'license': 'CC-BY-4.0', 'label_distributions': {k: dict(sorted(Counter(r[k] for r in source).items())) for k in ATTRIBUTES}})
    return inputs, labels

def build_chinese():
    cases = json.loads((ROOT / 'data/chinese/cases.source.json').read_text(encoding='utf-8'))
    # Keep related variants of one goal together, beyond identical prompts.
    families = {
        1:'cpp_bounds', 4:'cpp_bounds', 5:'cpp_bounds', 6:'cpp_bounds',
        2:'cpp_exceptions', 3:'cpp_capacity',
        7:'rate_denominator', 9:'rate_denominator', 10:'rate_denominator', 11:'rate_denominator',
        8:'causal_analysis', 20:'causal_analysis',
        12:'data_quality', 13:'data_quality', 15:'data_quality',
        14:'numeric_concepts', 16:'numeric_concepts', 17:'numeric_concepts',
        18:'arithmetic', 25:'arithmetic', 19:'learning', 32:'learning',
        21:'missing_context', 27:'missing_context',
        22:'writing_constraints', 28:'writing_constraints', 29:'writing_constraints', 31:'writing_constraints',
        23:'honesty', 24:'honesty', 26:'honesty', 30:'support'}
    splits = split_groups(families.values(), Counter(families.values()))
    inputs, labels, pairs = [], [], []
    for case in cases:
        group_id = case['group_id']
        family = families[int(group_id.split('-')[1])]
        split = splits[family]
        question_record, question_result = evaluation('question', case['q_dimensions'])
        pair_ids, scores = [], []
        for index, answer in enumerate(case['answers']):
            item_id = f'{group_id}-{index + 1}'
            pair_ids.append(item_id)
            inputs.append({'id': item_id, 'group_id': group_id, 'split': split, 'language': 'zh',
                           'origin': 'constructed_chinese', 'context': case['context'],
                           'question': case['question'], 'answer': answer['text'],
                           'tags': case['tags'], 'reference': case['reference'], 'leakage_group': family})
            answer_record, answer_result = evaluation('answer', answer['dimensions'], answer.get('gates'))
            scores.append(answer_result['score'])
            labels.append({'id': item_id, 'group_id': group_id, 'split': split,
                           'label_origin': 'codex_constructed_self_annotation', 'independent_of_author': False,
                           'human_reviewed': False, 'evidence_status': 'partial', 'confidence': 'medium',
                           'user_benefit': 'expected_not_observed', 'question_annotation_visibility': 'question_and_context_evidence_only; not an experimentally blinded run',
                           'question_record': question_record, 'question_result': question_result,
                           'answer_record': answer_record, 'answer_result': answer_result,
                           'question_improvement': case['question_improvement'],
                           'answer_improvement': answer['improvement']})
        if len(pair_ids) == 2:
            winner = 'unresolved' if None in scores else ('tie' if scores[0] == scores[1] else pair_ids[0 if scores[0] > scores[1] else 1])
            pairs.append({'id': group_id, 'group_id': group_id, 'split': split, 'answer_ids': pair_ids,
                          'preferred_id': winner, 'label_origin': 'derived_from_same_author_value_scores',
                          'independent_preference': False, 'ab_ba_stability': 'not_measured'})
    write_jsonl(ROOT / 'data/chinese/inputs.jsonl', inputs)
    write_jsonl(ROOT / 'data/chinese/labels.jsonl', labels)
    write_jsonl(ROOT / 'data/chinese/pairs.jsonl', pairs)
    with (ROOT / 'data/chinese/scores.csv').open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['id', 'group_id', 'split', 'question_score', 'question_bounds', 'answer_score', 'answer_bounds', 'answer_cap', 'human_reviewed'])
        for row in labels:
            q, a = row['question_result'], row['answer_result']
            writer.writerow([row['id'], row['group_id'], row['split'], q['score'], json.dumps(q['bounds']), a['score'], json.dumps(a['bounds']), a['cap'], False])
    return inputs, labels

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--refresh-source', action='store_true')
    args = parser.parse_args()
    public, _ = build_public(args.refresh_source)
    chinese, _ = build_chinese()
    write_json(ROOT / 'dataset_manifest.json', {
        'dataset_version': '0.1.0', 'rubric_version': '1.1', 'created_date': '2026-10-12',
        'split_seed': SEED, 'split_method': 'SHA256(seed:group); ordered prefix reaches floor(20%) prompt groups; related Chinese goal families are indivisible',
        'chinese_split_unit': 'related_goal_family (leakage_group); all answers and related variants stay together',
        'collections': {name: {'rows': len(rows), 'groups': len(set(r['group_id'] for r in rows)),
                               'split_rows': dict(Counter(r['split'] for r in rows))}
                        for name, rows in [('public', public), ('chinese', chinese)]},
        'independent_v11_human_labels': 0, 'external_accuracy_measured': False,
        'private_conversations_included': False, 'question_value_public_gold_available': False})
    print(json.dumps({'public_rows': len(public), 'chinese_rows': len(chinese)}, ensure_ascii=False))

if __name__ == '__main__':
    main()
