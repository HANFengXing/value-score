"""Compare saved public-axis predictions for one split; never generate predictions."""
import argparse
import importlib.util
import json
from pathlib import Path
from build_dataset import ROOT, REVISION

SPEC=importlib.util.spec_from_file_location('public_benchmark',ROOT/'skills/value-score/scripts/benchmark.py')
BENCHMARK=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BENCHMARK)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('predictions',type=Path)
    parser.add_argument('--split',choices=['calibration','holdout','all'],default='holdout')
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    all_gold=BENCHMARK.read_rows(ROOT/'data/public/labels.jsonl')
    gold={i:row for i,row in all_gold.items() if args.split=='all' or row['split']==args.split}
    predictions=BENCHMARK.read_rows(args.predictions,prediction=True)
    report=BENCHMARK.compare(gold,predictions)
    report.update({'dataset':'nvidia/HelpSteer2','revision':REVISION,'package_split':args.split,
                   'personal_value_score_accuracy':'not_measured'})
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='derived_pairwise_helpfulness'},ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
