"""Train grouped-CV TF-IDF models on calibration rows, then evaluate saved holdout predictions."""
import argparse
import hashlib
import importlib.util
import json
import math
import platform
import time
from collections import Counter
from pathlib import Path

import numpy as np
import scipy
import sklearn
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.model_selection import GroupKFold

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('training_runtime', ROOT / 'skills/value-score/scripts/model_runtime.py')
RUNTIME = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUNTIME)
ALPHAS = (.3, 1., 3., 10., 30.)
CS = (.3, 1., 3.)
SEED = 20261012
TASKS = {
    'public_answer': {'collection': 'public', 'kind': 'answer',
        'dimensions': ('helpfulness', 'correctness', 'coherence'),
        'label_source': 'HelpSteer2 original human annotations; same dataset builder did not author them',
        'features': [dict(source='question', analyzer='word', ngram_range=[1,2], min_df=2, max_features=6000),
                     dict(source='answer', analyzer='word', ngram_range=[1,2], min_df=2, max_features=18000),
                     dict(source='answer', analyzer='char_wb', ngram_range=[2,5], min_df=2, max_features=18000)]},
    'chinese_question': {'collection': 'chinese', 'kind': 'question',
        'dimensions': ('importance', 'unknown', 'leverage', 'researchability'),
        'label_source': 'Codex constructed author self-annotation, not independent human gold',
        'features': [dict(source='question', analyzer='char', ngram_range=[1,3], min_df=1, max_features=6000)]},
    'chinese_answer': {'collection': 'chinese', 'kind': 'answer',
        'dimensions': ('alignment', 'reliability', 'gain', 'efficiency', 'cap_risk'),
        'label_source': 'Codex constructed author self-annotation, not independent human gold',
        'features': [dict(source='question', analyzer='char', ngram_range=[1,3], min_df=1, max_features=2500),
                     dict(source='answer', analyzer='char', ngram_range=[1,4], min_df=1, max_features=6000)]},
}


def write_json(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def write_jsonl(path, rows):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in rows), encoding='utf-8')


def load_rows(collection, split, kind):
    inputs = [r for r in RUNTIME.read_jsonl(ROOT / f'data/{collection}/inputs.jsonl') if r['split'] == split]
    if kind == 'question':
        inputs = list({r['group_id']: r for r in inputs}.values())
    return inputs


def targets(rows, config, labels):
    values = {n: [] for n in config['dimensions']}
    for row in rows:
        label = labels[row['id']]
        for name in values:
            if config['collection'] == 'public':
                value = label[name]
            elif name == 'cap_risk':
                value = int(bool(label['answer_record']['gates']))
            else:
                dim = label[config['kind'] + '_record']['dimensions'][name]
                value = dim['level'] if dim['status'] == 'scored' else np.nan
            values[name].append(value)
    return {name: np.array(v, dtype=float) for name, v in values.items()}


def fit_head(matrix, target, parameter, binary=False):
    mask = np.isfinite(target)
    y = target[mask]
    if not len(y):
        raise ValueError('No known training labels')
    if len(np.unique(y)) == 1:
        if binary:
            # Constant class represented as a saturated logistic intercept.
            return np.zeros(matrix.shape[1]), (40. if y[0] else -40.), 'binary_logistic'
        return np.zeros(matrix.shape[1]), float(y[0]), 'constant'
    if binary:
        fitted = LogisticRegression(C=parameter, solver='liblinear', class_weight='balanced', random_state=SEED).fit(matrix[mask], y.astype(int))
        return fitted.coef_[0], float(fitted.intercept_[0]), 'binary_logistic'
    fitted = Ridge(alpha=parameter, solver='lsqr', tol=1e-5).fit(matrix[mask], y)
    return fitted.coef_, float(fitted.intercept_), 'ridge'


def predict_head(matrix, coefficient, intercept, binary):
    value = np.asarray(matrix @ coefficient).reshape(-1) + intercept
    return 1 / (1 + np.exp(-np.clip(value, -40, 40))) if binary else np.clip(value, 0, 4)


def rounded(values, binary=False):
    return (values >= .5).astype(int) if binary else np.floor(np.clip(values, 0, 4) + .5).astype(int)


def metrics(gold, prediction):
    mask = np.isfinite(gold)
    g, p = gold[mask], prediction[mask]
    if not len(g):
        return {'n': 0, 'mae': None, 'exact_agreement': None, 'within_one_level': None, 'quadratic_weighted_kappa': None}
    gc, pc = Counter(g), Counter(p)
    observed = float(np.mean((g-p)**2))
    expected = sum(gc[a]*pc[b]*(a-b)**2 for a in gc for b in pc)/(len(g)**2)
    return {'n': len(g), 'mae': float(np.mean(np.abs(g-p))), 'exact_agreement': float(np.mean(g == p)),
            'within_one_level': float(np.mean(np.abs(g-p) <= 1)),
            'mean_signed_error_prediction_minus_label': float(np.mean(p-g)),
            'quadratic_weighted_kappa': float(1-observed/expected) if expected else None,
            'label_distribution': dict(sorted((str(int(k)),v) for k,v in gc.items())),
            'prediction_distribution': dict(sorted((str(int(k)),v) for k,v in pc.items()))}


def grouped_mae_interval(gold, prediction, groups, repeats=1000):
    mask = np.isfinite(gold)
    valid_groups = sorted(set(groups[mask]))
    if len(valid_groups) < 2:
        return None
    totals = np.array([np.abs(gold[(groups == g) & mask] - prediction[(groups == g) & mask]).sum() for g in valid_groups])
    counts = np.array([((groups == g) & mask).sum() for g in valid_groups])
    draws = np.random.default_rng(SEED).integers(0, len(valid_groups), size=(repeats, len(valid_groups)))
    estimates = totals[draws].sum(axis=1) / counts[draws].sum(axis=1)
    return {'method': 'percentile bootstrap by related goal family or prompt; descriptive, not external validation',
            'independent_groups': len(valid_groups), 'repeats': repeats, 'interval_95': np.quantile(estimates, [.025,.975]).tolist()}


def cross_validate(rows, target_map, config):
    groups = np.array([r.get('leakage_group', r['group_id']) for r in rows])
    folds = list(GroupKFold(n_splits=min(3, len(set(groups)))).split(rows, groups=groups))
    predictions = {name: {str(p): np.full(len(rows), np.nan) for p in (CS if name == 'cap_risk' else ALPHAS)} for name in target_map}
    baseline = {name: np.full(len(rows), np.nan) for name in target_map}
    for fit_ids, valid_ids in folds:
        banks, train_matrix = RUNTIME.fit_features([rows[i] for i in fit_ids], config['features'])
        valid_matrix = RUNTIME.transform_features([rows[i] for i in valid_ids], banks)
        for name, target in target_map.items():
            fit_target = target[fit_ids]
            known = fit_target[np.isfinite(fit_target)]
            if not len(known):
                continue
            binary = name == 'cap_risk'
            baseline[name][valid_ids] = float(np.median(known))
            for parameter in (CS if binary else ALPHAS):
                coefficient, intercept, _ = fit_head(train_matrix, fit_target, parameter, binary)
                predictions[name][str(parameter)][valid_ids] = predict_head(valid_matrix, coefficient, intercept, binary)
    selected, summaries = {}, {}
    for name, candidates in predictions.items():
        y = target_map[name]
        mask = np.isfinite(y)
        binary = name == 'cap_risk'
        losses = {parameter: float(np.mean(np.abs(rounded(values[mask], binary)-y[mask]))) for parameter, values in candidates.items()}
        # Tie goes to stronger regularization; no holdout-based selection.
        winner = min(losses, key=lambda p: (losses[p], -float(p)))
        selected[name] = float(winner)
        summaries[name] = {'selected_parameter': float(winner), 'parameter_kind': 'C' if binary else 'alpha',
                           'ordinal_mae_by_parameter': losses,
                           'fold_median_baseline_mae': float(np.mean(np.abs(rounded(baseline[name][mask], binary)-y[mask]))),
                           'valid_labels': int(mask.sum())}
    return selected, {'folds': len(folds), 'group_unit': 'leakage_group when present, otherwise group_id',
                     'vectorizers_refit_inside_each_fold': True, 'heads': summaries}


def train(out, reports):
    started = time.perf_counter()
    vocabularies, arrays, manifests, audit = {}, {}, {}, {}
    full_report = {'model_id': 'value-score-tfidf-ridge-v1', 'model_version': '1.0.0', 'created_date': '2026-10-12',
                   'algorithm': 'TF-IDF + per-dimension Ridge; binary logistic cap-review signal',
                   'neural_or_llm_finetuning': False, 'seed': SEED, 'selection': '3-fold grouped CV on calibration only',
                   'tasks': {}, 'personal_independent_human_accuracy': 'not_measured',
                   'public_source': 'https://huggingface.co/datasets/nvidia/HelpSteer2/tree/990b2711a36180dd19d9c94b8627844866f8982a',
                   'limitations': ['Small English subset; labels are English and do not verify facts at inference time.',
                                   'Chinese targets are same-author self-annotations, not human gold.',
                                   'Question-value labels are sparse and often constant.',
                                   'Predicted risk does not confirm any serious-error gate.',
                                   'No real AB/BA or independent reviewer test performed.']}
    all_training_labels = {}
    for collection in ('public', 'chinese'):
        # Holdout labels stay outside model fitting and hyperparameter selection.
        all_training_labels[collection] = {r['id']: r for r in RUNTIME.read_jsonl(ROOT / f'data/{collection}/labels.jsonl') if r['split'] == 'calibration'}
    for task, config in TASKS.items():
        rows = load_rows(config['collection'], 'calibration', config['kind'])
        held = load_rows(config['collection'], 'holdout', config['kind'])
        train_groups = {r.get('leakage_group', r['group_id']) for r in rows}
        held_groups = {r.get('leakage_group', r['group_id']) for r in held}
        if train_groups & held_groups:
            raise ValueError('Train/holdout group overlap')
        target_map = targets(rows, config, all_training_labels[config['collection']])
        selected, cv = cross_validate(rows, target_map, config)
        banks, matrix = RUNTIME.fit_features(rows, config['features'])
        for i, (_, fitted) in enumerate(banks):
            vocabularies[f'{task}_{i}'] = {k: int(v) for k,v in fitted.vocabulary_.items()}
            arrays[f'{task}_idf_{i}'] = fitted.idf_
        head_meta, held_predictions = {}, []
        held_matrix = RUNTIME.transform_features(held, banks)
        predictions, baselines = {}, {}
        for name, target in target_map.items():
            known = target[np.isfinite(target)]
            binary = name == 'cap_risk'
            coefficient, intercept, head_type = fit_head(matrix, target, selected[name], binary)
            key = f'{task}_{name}'
            arrays[key + '_coef'] = coefficient
            arrays[key + '_intercept'] = np.array([intercept])
            predictions[name] = predict_head(held_matrix, coefficient, intercept, binary)
            baselines[name] = np.full(len(held), float(np.median(known)))
            head_meta[name] = {'type': head_type, 'parameter': selected[name], 'training_rows': len(known),
                               'excluded_unknown_or_na': len(rows)-len(known), 'unique_levels': sorted(int(v) for v in np.unique(known))}
        for i, row in enumerate(held):
            held_predictions.append({'id': row['id'], 'group_id': row['group_id'],
                'continuous': {n: float(p[i]) for n,p in predictions.items()},
                'levels': {n: int(rounded(p, n == 'cap_risk')[i]) for n,p in predictions.items()}})
        write_jsonl(reports / f'{task}.holdout.predictions.jsonl', held_predictions)
        # Persist blind predictions before obtaining holdout targets for evaluation.
        held_labels = {r['id']: r for r in RUNTIME.read_jsonl(ROOT / f'data/{config["collection"]}/labels.jsonl') if r['split'] == 'holdout'}
        held_targets = targets(held, config, held_labels)
        groups = np.array([r.get('leakage_group', r['group_id']) for r in held])
        results = {}
        for name, gold in held_targets.items():
            pred = rounded(predictions[name], name == 'cap_risk')
            base = rounded(baselines[name], name == 'cap_risk')
            result = metrics(gold, pred)
            result['baseline_train_median'] = metrics(gold, base)
            result['beats_baseline_mae'] = result['mae'] < result['baseline_train_median']['mae']
            result['grouped_mae_95'] = grouped_mae_interval(gold, pred, groups)
            result['continuous_mae'] = float(np.mean(np.abs(predictions[name][np.isfinite(gold)]-gold[np.isfinite(gold)])))
            if name == 'cap_risk':
                tp, fp, fn = int(((pred == 1)&(gold == 1)).sum()), int(((pred == 1)&(gold == 0)).sum()), int(((pred == 0)&(gold == 1)).sum())
                result.update({'true_positive': tp, 'false_positive': fp, 'false_negative': fn,
                               'precision': tp/(tp+fp) if tp+fp else None, 'recall': tp/(tp+fn) if tp+fn else None,
                               'interpretation': 'Agreement with author supplied gate-presence labels; not fact checking'})
            results[name] = result
        manifests[task] = {'features': config['features'], 'heads': head_meta, 'label_source': config['label_source'],
                           'kind': config['kind'], 'training_rows': len(rows), 'training_groups': len(train_groups),
                           'holdout_rows': len(held), 'holdout_groups': len(held_groups)}
        audit[task] = {'train_ids': [r['id'] for r in rows], 'holdout_ids': [r['id'] for r in held],
                       'train_groups': sorted(train_groups), 'holdout_groups': sorted(held_groups)}
        full_report['tasks'][task] = {**manifests[task], 'cross_validation': cv, 'holdout_metrics': results,
                                     'average_ordinal_mae': float(np.mean([v['mae'] for k,v in results.items() if k != 'cap_risk'])),
                                     'deployment_status': 'advisory_only; evidence review required'}
        print(json.dumps({'task': task, 'training_rows': len(rows), 'holdout_rows': len(held),
                          'mae': {k: round(v['mae'],4) for k,v in results.items()},
                          'baseline_mae': {k: round(v['baseline_train_median']['mae'],4) for k,v in results.items()}}, ensure_ascii=False), flush=True)
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / 'vocabulary.json', vocabularies)
    np.savez_compressed(out / 'weights.npz', **arrays)
    manifest = {'format_version': 1, 'model_id': full_report['model_id'], 'version': '1.0.0',
                'rubric_version': '1.1', 'mode': 'advisory_only', 'tasks': manifests,
                'artifacts_sha256': {f: RUNTIME.sha256(out/f) for f in ('vocabulary.json','weights.npz')},
                'dependencies': {'python': platform.python_version(), 'numpy': np.__version__, 'scipy': scipy.__version__, 'scikit-learn': sklearn.__version__},
                'source_hashes': {f'data/{c}/{f}.jsonl': RUNTIME.sha256(ROOT/f'data/{c}/{f}.jsonl') for c in ('public','chinese') for f in ('inputs','labels')}}
    write_json(out / 'model.json', manifest)
    write_json(reports / 'training_split_audit.json', audit)
    full_report['elapsed_seconds'] = time.perf_counter()-started
    full_report['runtime_versions'] = manifest['dependencies']
    write_json(reports / 'training_report.json', full_report)
    # Check exported numerical/JSON artifacts reproduce in-memory predictions exactly.
    loaded = RUNTIME.ScoreModel(out)
    for task, config in TASKS.items():
        held = load_rows(config['collection'], 'holdout', config['kind'])
        saved = {r['id']: r for r in RUNTIME.read_jsonl(reports / f'{task}.holdout.predictions.jsonl')}
        actual = loaded.predict_raw(task, held)
        for name, values in actual.items():
            np.testing.assert_allclose(values, [saved[r['id']]['continuous'][name] for r in held], rtol=1e-10, atol=1e-10)
    print(json.dumps({'status': 'trained_and_reload_verified', 'model_dir': str(out), 'seconds': round(full_report['elapsed_seconds'],2)}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT/'skills/value-score/models/baseline-v1')
    parser.add_argument('--reports', type=Path, default=ROOT/'reports/model')
    args = parser.parse_args()
    train(args.out, args.reports)


if __name__ == '__main__':
    main()
