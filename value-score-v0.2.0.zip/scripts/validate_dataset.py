"""Check data integrity and score arithmetic; does not measure judge accuracy."""
import argparse
import gzip
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
from build_dataset import ROOT, SCORER, ATTRIBUTES, REVISION, split_groups

def require(condition, message):
    if not condition:
        raise ValueError(message)

def read_rows(path):
    rows = []
    lines = path.read_text(encoding='utf-8').split('\n')
    if lines[-1] == '':
        lines.pop()
    for number, line in enumerate(lines, 1):
        require(bool(line.strip()), f'{path}:{number}: empty line')
        rows.append(json.loads(line))
    ids = [r['id'] for r in rows]
    require(len(ids) == len(set(ids)), f'{path}: duplicate IDs')
    return rows

def check_collection(name):
    inputs = read_rows(ROOT / f'data/{name}/inputs.jsonl')
    labels = read_rows(ROOT / f'data/{name}/labels.jsonl')
    by_id = {r['id']: r for r in labels}
    require(set(by_id) == {r['id'] for r in inputs}, f'{name}: missing/extraneous labels')
    split_seen = defaultdict(set)
    family_seen = defaultdict(set)
    for row in inputs:
        require(row['split'] in ('calibration','holdout'), f'{name}: invalid split')
        require(all(isinstance(row[k],str) and row[k] for k in ('question','answer')), f'{row["id"]}: empty text')
        split_seen[row['group_id']].add(row['split'])
        family_seen[row.get('leakage_group',row['group_id'])].add(row['split'])
        label = by_id[row['id']]
        require(label['split'] == row['split'] and label['group_id'] == row['group_id'], f'{row["id"]}: split/group mismatch')
    require(all(len(x)==1 for x in split_seen.values()), f'{name}: prompt leakage')
    require(all(len(x)==1 for x in family_seen.values()), f'{name}: related goal leakage')
    if name == 'chinese':
        weights = Counter()
        seen = set()
        for row in inputs:
            if row['group_id'] not in seen:
                seen.add(row['group_id'])
                weights[row['leakage_group']] += 1
        expected_splits = split_groups(family_seen, weights)
    else:
        expected_splits = split_groups(family_seen)
    for row in inputs:
        family = row.get('leakage_group',row['group_id'])
        require(expected_splits[family] == row['split'], f'{row["id"]}: nondeterministic split')
    return inputs, labels

def validate():
    manifest = json.loads((ROOT/'dataset_manifest.json').read_text(encoding='utf-8'))
    report = {'status':'passed', 'rubric_version':'1.1', 'checks': [], 'collections':{},
              'judge_accuracy':'not_measured', 'ab_ba_stability':'not_measured',
              'human_review_of_chinese':'not_performed'}
    public, public_labels = check_collection('public')
    archive = ROOT/'data/helpsteer2-validation.source.jsonl.gz'
    raw = gzip.decompress(archive.read_bytes())
    original = [json.loads(line) for line in raw.splitlines() if line.strip()]
    provenance = json.loads((ROOT/'data/public/provenance.json').read_text(encoding='utf-8'))
    require(provenance['revision']==REVISION, 'Unexpected public revision')
    require(provenance['archive_sha256']==hashlib.sha256(archive.read_bytes()).hexdigest(), 'Archive hash mismatch')
    require(provenance['decompressed_sha256']==hashlib.sha256(raw).hexdigest(), 'Decompressed hash mismatch')
    require(len(public)==len(original)==1038, 'Incomplete HelpSteer2 validation split')
    for row, label, source in zip(public,public_labels,original):
        require(row['question']==source['prompt'] and row['answer']==source['response'], f'{row["id"]}: source text changed')
        for axis in ATTRIBUTES:
            require(type(label[axis]) is int and 0<=label[axis]<=4, f'{row["id"]}: invalid public label')
            require(label[axis]==source[axis], f'{row["id"]}: original label changed')
        require(label['composite_value_score'] is None, 'Public labels improperly mapped to personal value score')
        require(label['label_origin']=='upstream_human_annotation', 'Incorrect public provenance')
    report['checks'].extend(['complete_public_split_and_original_text', 'all_five_original_human_axes', 'pinned_source_hashes'])
    chinese, chinese_labels = check_collection('chinese')
    require(len(chinese)==64, 'Expected 64 Chinese answers')
    for row in chinese_labels:
        require(row['human_reviewed'] is False and row['independent_of_author'] is False, 'Misrepresented independence')
        for kind in ('question','answer'):
            result = SCORER.evaluate(row[f'{kind}_record'])
            expected = row[f'{kind}_result']
            require(all(result[k]==expected[k] for k in expected), f'{row["id"]}/{kind}: arithmetic mismatch')
            if result['bounds'] is not None:
                require(result['score'] is None and result['bounds'][0]<=result['bounds'][1], 'Invalid interval')
    q_records = defaultdict(list)
    for row in chinese_labels:
        q_records[row['group_id']].append(row['question_record'])
    require(all(all(x==rows[0] for x in rows) for rows in q_records.values()), 'Question score depends on answer variant')
    by_id = {r['id']: r for r in chinese_labels}
    pairs = read_rows(ROOT/'data/chinese/pairs.jsonl')
    paired_ids = []
    for pair in pairs:
        ids = pair['answer_ids']
        require(len(ids)==2 and len(set(ids))==2, 'Pair needs two distinct IDs')
        require(all(i in by_id and by_id[i]['group_id']==pair['group_id'] and by_id[i]['split']==pair['split'] for i in ids), 'Invalid pair membership')
        paired_ids.extend(ids)
        scores = [by_id[i]['answer_result']['score'] for i in ids]
        winner = 'unresolved' if None in scores else ('tie' if scores[0]==scores[1] else ids[0 if scores[0]>scores[1] else 1])
        require(pair['preferred_id']==winner, 'Pair preference inconsistent with recorded scores')
        require(pair['independent_preference'] is False and pair['ab_ba_stability']=='not_measured', 'Overstated preference evidence')
    require(sorted(paired_ids)==sorted(by_id), 'Pair coverage incomplete/duplicated')
    report['checks'].extend(['unique_ids_and_exact_label_joins','no_prompt_or_goal_family_split_leakage',
                            'v11_dimension_evidence_and_recomputed_scores','unknown_intervals_and_caps',
                            'question_scores_equal_across_answer_variants','honest_annotation_provenance','pair_coverage_and_derived_ties'])
    for name, rows in [('public',public),('chinese',chinese)]:
        counts = {'rows':len(rows),'groups':len(set(r['group_id'] for r in rows)), 'split_rows':dict(Counter(r['split'] for r in rows))}
        require(counts==manifest['collections'][name], f'{name}: manifest mismatch')
        report['collections'][name] = counts
    report['chinese_answer_caps'] = dict(Counter(g['type'] for r in chinese_labels for g in r['answer_record']['gates']))
    report['chinese_interval_records'] = {k:sum(r[f'{k}_result']['bounds'] is not None for r in chinese_labels) for k in ('question','answer')}
    report['chinese_answer_score_distribution'] = dict(sorted(Counter(r['answer_result']['score'] for r in chinese_labels if r['answer_result']['score'] is not None).items()))
    report['ties'] = sum(r['preferred_id']=='tie' for r in pairs)
    report['unresolved_pairs'] = sum(r['preferred_id']=='unresolved' for r in pairs)
    report['files_sha256'] = {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in sorted((ROOT/'data').rglob('*')) if p.is_file()}
    return report

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=ROOT/'reports/validation.json')
    args = parser.parse_args()
    report = validate()
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='files_sha256'},ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
