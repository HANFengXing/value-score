"""Build the dataset + trained-model release without review logs or cache files."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION = '0.2.0'


def render():
    report = json.loads((ROOT/'reports/model/training_report.json').read_text(encoding='utf-8'))
    table = ['| 模型 / 维度 | 留出有效标签 | 模型MAE | 常数基线MAE |', '|---|---:|---:|---:|']
    for task, item in report['tasks'].items():
        for dimension, result in item['holdout_metrics'].items():
            table.append(f'| {task} / {dimension} | {result["n"]} | {result["mae"]:.3f} | {result["baseline_train_median"]["mae"]:.3f} |')
    card = f'''# value-score 本地模型 v1.0.0

这是已实际训练并导出权重的CPU文本模型，采用TF-IDF + Ridge分维回归；严重错误复核信号用逻辑回归。没有微调大语言模型。

技能版本1.2，个人量表仍为1.1；模型版本1.0.0，分发包{VERSION}。模型只能提供实验性预评分，不能核验事实、确认严重错误或证明用户收益。

## 训练和评测

| 部分 | 训练 | 留出 | 标签 |
|---|---:|---:|---|
| 英文回答 | 832回答 / 416问题 | 206回答 / 103问题 | HelpSteer2原始人工标签 |
| 中文回答 | 50回答 / 25问题 | 14回答 / 7问题 | 同作者构造并自评，未人工复核 |
| 中文问题 | 25个独立问题 | 7个独立问题 | 同作者自评，未知标签剔除 |

相关中文目标家族不跨集合，问题训练不重复使用两个回答。固定原数据划分、随机种子20261012，三折按组交叉验证仅在训练部分选择正则化参数，词表与IDF在各折重新学习。保存留出预测后，再取留出标签评测。参考答案、标签、作者、ID、来源和回答顺序不作为特征。

以下是0–4级的MAE，越低越好；cap_risk为0/1错误复核信号。常数基线只使用训练标签中位数，没有看留出标签。

{chr(10).join(table)}

英文有用性、正确性未优于常数基线，连贯性只有极小差异。中文问题预测与基线相同，关键未知训练标签只有一个等级，不能用低误差宣称学到了问题价值。中文回答四维平均MAE为0.897，基线1.195；这是14条作者自评标签的一致性，不能称为独立人工准确率。

完整逐维精确一致率、相差不超过一级、二次加权κ、分布、偏差、按独立问题/目标家族bootstrap区间见[training_report.json](training_report.json)，包内也保留盲预测与划分审计。不把接近常数的高一致率当成理解能力。没有真实AB/BA或长期用户结果记录。

## 运行与接入

完整分发包的`skills/value-score/models/baseline-v1/`包含model.json、vocabulary.json和weights.npz。NPZ使用allow_pickle=False，入口检查SHA256；无外部API调用。

```powershell
python skills/value-score/scripts/score.py examples/predict-input.json --predict --kind answer
python skills/value-score/scripts/score.py examples/predict-input.json --predict --kind question
python scripts/train_model.py
python -m unittest discover -s tests -v
```

预测输出含分维建议、中文未应用错误上限的预评分、复核信号。正式等级初始全部unknown，verified_result为待评范围0–100；先核验材料，再用原计分器计算正式分数。严重错误信号不是校准概率，也不自动触发39/49分上限。

中文优先用于提示复核；英文模型仅用于明确请求的预测/对照。正式评分遵循原证据与区间规则。技能仅使用当前授权的问答，不读取其他聊天，不保存长期日志。

## 适用边界

词法模型易学习风格、措辞和主题，无法验证复杂推理或事实。英文832条训练样本很少，中文仅50条作者自评回答，缺独立中文人工标签。对新领域、新语言、长文本及事实细节的外推不可靠。现有留出结果已公开，后续根据它调参时必须用新增独立标签验证，不能反复刷这一组分数。

复用应保留模型建议与最终证据评分的分歧；优先补充中文独立人工标签、真实目标背景，以及正确/流畅错误/缺证据/篇幅变化的配对案例。

## 来源与依赖

数据归属NVIDIA，[HelpSteer2固定版本](https://huggingface.co/datasets/nvidia/HelpSteer2/tree/990b2711a36180dd19d9c94b8627844866f8982a)，CC-BY-4.0。第三方数据、派生英文模型与署名见THIRD_PARTY_NOTICES.md。中文标签与其模型是构造自评，不冒充人工来源。

已验证Python3.11.7、numpy1.26.4、scipy1.11.4、scikit-learn1.2.2。方法参考[TF-IDF文档](https://scikit-learn.org/1.2/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html)与[Ridge文档](https://scikit-learn.org/1.2/modules/generated/sklearn.linear_model.Ridge.html)。
'''
    (ROOT/'MODEL_CARD.md').write_text(card, encoding='utf-8')
    shutil.copy2(ROOT/'reports/model/training_report.json', ROOT/'training_report.json')
    readme = f'''# value-score

问答价值评分技能1.2、回答—评分数据集0.1.0，以及已训练的本地模型1.0.0，合并发布为分发包{VERSION}。

[下载最新完整包](https://github.com/HANFengXing/value-score/blob/master/value-score-v{VERSION}.zip) · [模型与评测说明](MODEL_CARD.md) · [实际训练报告](training_report.json) · [中文标签预览](scores.csv) · [数据卡](DATASET_CARD.md)

## 已交付

- 1038条HelpSteer2原始人工评分回答，519个问题；固定来源版本与CC-BY-4.0署名。
- 64条中文构造回答、32个问题，附量表分维等级、证据、缺证据区间和改进方向；这些是作者自评，未人工复核。
- 已训练TF-IDF + Ridge模型权重：英文三个原始人工维度、中文问答八个个人量表维度；严重错误复核信号另用逻辑回归。
- 技能1.2接入本地模型入口，原量表1.1、权重、未知区间和错误上限保留。
- 训练代码、模型文件、逐维留出评测、按组划分审计和15项测试。

英文有用性和正确性没有优于常数基线，中文问题预测也未改善。中文回答四维平均MAE 0.897，基线1.195，但只对14条构造自评回答评测。模型当前用于实验性辅助复核，不宣称独立人工准确率或自动事实核验。详见模型卡。

## 下载运行

仓库通过完整ZIP保留目录结构，先下载再解压。需要Python3.11；原有计分和数据检查只用标准库，模型需要requirements-model.txt中的依赖。

```powershell
python -m zipfile -e value-score-v{VERSION}.zip value-score-package
cd value-score-package
python -m pip install -r requirements-model.txt
python skills/value-score/scripts/score.py examples/predict-input.json --predict --kind answer
python skills/value-score/scripts/score.py examples/predict-input.json --predict --kind question
```

输出提供`dimension_predictions`和中文`provisional_uncapped_index`；它们未经内容核验。`verified_result`初始为待评范围0–100，正式等级由证据记录决定。检查证据后，原命令`python skills/value-score/scripts/score.py evaluation.json`照常计算。

## 重训与检查

```powershell
python scripts/train_model.py
python scripts/validate_dataset.py
python -m unittest discover -s tests -v
```

训练仅使用calibration，三折按问题/相关目标家族隔离，留出预测先保存后评测。输入只有context/question/answer，参考答案与标签不进入特征。未知维度不作为0分训练，不将公共标签映射为个人价值总分，也不根据模型信号确认严重错误。

## 包内结构

```text
skills/value-score/          技能1.2、量表1.1、计分和本地预测入口
  models/baseline-v1/        已训练的JSON词表、元数据、NPZ数值权重
data/public/                英文问题回答与原始五项人工标签
data/chinese/               中文问答、自评分维依据与成对记录
scripts/train_model.py      真正训练与保存模型；无外部API
reports/model/              盲留出预测、训练报告与划分审计
examples/                   可运行的预测输入
tests/                      计分、数据隔离、未知标签、权重复载与证据边界检查
docs/                       数据卡和字段说明
requirements-model.txt      此次训练的精确依赖版本
```

本地技能接入时复制包内整个`skills/value-score`目录，包括models，先备份已有版本。技能辅助评分只使用当前授权材料，不读取其他聊天，不自动记录长期日志。

旧版[value-score-v0.1.0.zip](https://github.com/HANFengXing/value-score/blob/master/value-score-v0.1.0.zip)保留数据与原skill1.1。数据本体仍是0.1.0；新增的是训练代码、模型与技能接入。
'''
    (ROOT/'README.md').write_text(readme, encoding='utf-8')
    original_card = ROOT/'docs/DATASET_CARD.md'
    content = original_card.read_text(encoding='utf-8')
    note = '本数据卡描述原始数据集0.1.0；新增模型的实际训练、留出结果和限制见分发包MODEL_CARD.md与reports/model/training_report.json。原数据标签、划分和来源没有改动。\n\n'
    if note not in content:
        original_card.write_text(note + content, encoding='utf-8')
    shutil.copy2(original_card, ROOT/'DATASET_CARD.md')
    notices = ROOT/'THIRD_PARTY_NOTICES.md'
    notice = '\n\n## 新增本地模型\n\n英文模型参数由上述NVIDIA HelpSteer2固定版本数据训练而来，保留原数据CC-BY-4.0署名及来源；训练和JSON/NPZ转换为本次修改。中文参数由已明确标注的构造自评标签训练，不是独立人工金标准。第三方库未打包，仅在requirements-model.txt声明依赖。\n'
    if '## 新增本地模型' not in notices.read_text(encoding='utf-8'):
        with notices.open('a', encoding='utf-8') as stream:
            stream.write(notice)
    model_files = ROOT/'skills/value-score/models/baseline-v1'
    manifest = {'package_version': VERSION, 'dataset_version': '0.1.0', 'skill_version': '1.2',
                'rubric_version': '1.1', 'model_version': '1.0.0', 'model_trained': True,
                'public_axis_holdout_agreement_measured': True, 'independent_chinese_human_accuracy_measured': False,
                'automatic_verified_scoring': False,
                'model_artifacts_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(model_files.iterdir()) if p.is_file()}}
    (ROOT/'package_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def package():
    render()
    archive = ROOT.parent / f'value-score-v{VERSION}.zip'
    members = []
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in sorted(ROOT.rglob('*')):
            relative = path.relative_to(ROOT)
            if not path.is_file() or any(x in ('__pycache__', 'review', '.git', '.venv') for x in relative.parts) or path.suffix == '.pyc':
                continue
            output.write(path, relative.as_posix())
            members.append(relative.as_posix())
    with zipfile.ZipFile(archive) as check:
        if check.testzip() is not None:
            raise ValueError('Archive CRC failure')
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    archive.with_suffix('.zip.sha256').write_text(f'{digest}  {archive.name}\n', encoding='ascii')
    print(json.dumps({'archive': str(archive), 'files': len(members), 'bytes': archive.stat().st_size, 'sha256': digest}, ensure_ascii=False))


if __name__ == '__main__':
    package()
