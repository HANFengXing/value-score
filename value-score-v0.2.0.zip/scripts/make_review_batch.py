"""Export separate question/answer tasks without existing scores or reference keys."""
import argparse
import json
from pathlib import Path
from build_dataset import ROOT, write_jsonl

def export(collection,split,out):
    rows = [json.loads(line) for line in (ROOT/f'data/{collection}/inputs.jsonl').read_text(encoding='utf-8').split('\n') if line]
    selected = [r for r in rows if split=='all' or r['split']==split]
    if not selected:
        raise ValueError('No rows selected')
    questions, seen = [], set()
    for row in selected:
        if row['group_id'] not in seen:
            seen.add(row['group_id'])
            questions.append({k:row[k] for k in ('group_id','context','question')})
    answers = [{k:row[k] for k in ('id','group_id','context','question','answer')} for row in selected]
    out.mkdir(parents=True,exist_ok=True)
    write_jsonl(out/'questions.blind.jsonl', questions)
    write_jsonl(out/'answers.blind.jsonl', answers)
    if collection=='public':
        template = [{'id':r['id'],'pair_id':r['group_id'],'helpfulness':None,'correctness':None,'coherence':None} for r in selected]
    else:
        template = [{'id':r['id'],'question_record':None,'answer_record':None,'reviewer_id':None,
                     'independent_of_author':None,'human_reviewed':None} for r in selected]
    write_jsonl(out/'annotations.template.jsonl',template)
    print(json.dumps({'collection':collection,'split':split,'questions':len(questions),'answers':len(answers),'out':str(out)},ensure_ascii=False))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collection',choices=['public','chinese'],default='chinese')
    parser.add_argument('--split',choices=['calibration','holdout','all'],default='holdout')
    parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args()
    export(args.collection,args.split,args.out)

if __name__=='__main__':
    main()
