"""Validate evidence records and calculate a value index. No model/API calls."""
import argparse
import json
from decimal import Decimal, ROUND_HALF_UP, ROUND_FLOOR, ROUND_CEILING
from pathlib import Path

WEIGHTS = {
    'question': {'importance': 30, 'unknown': 30, 'leverage': 25, 'researchability': 15},
    'answer': {'alignment': 30, 'reliability': 30, 'gain': 25, 'efficiency': 15},
}
CAPS = {'confirmed_core_error': 39, 'fabricated_source': 39,
        'false_completion': 39, 'off_topic': 39, 'promise_only': 49}

def nonempty(value):
    return isinstance(value, str) and bool(value.strip())

def evaluate(record):
    if not isinstance(record, dict) or record.get('rubric_version') != '1.1':
        raise ValueError('Expected rubric_version 1.1')
    kind = record.get('kind')
    if kind not in WEIGHTS:
        raise ValueError('kind must be question or answer')
    dimensions = record.get('dimensions')
    if not isinstance(dimensions, dict) or set(dimensions) != set(WEIGHTS[kind]):
        raise ValueError('Must supply exactly the four dimensions for this kind')
    total_weight, known_weight, unknown_weight = 0, 0, 0
    known_points = Decimal(0)
    trace = []
    for name, weight in WEIGHTS[kind].items():
        item = dimensions[name]
        if not isinstance(item, dict):
            raise ValueError(f'{name}: expected object')
        status, level = item.get('status'), item.get('level')
        if status not in ('scored', 'unknown', 'na'):
            raise ValueError(f'{name}: invalid status')
        if status == 'scored':
            if type(level) is not int or not 0 <= level <= 4:
                raise ValueError(f'{name}: expected integer 0..4; booleans invalid')
            if not nonempty(item.get('evidence')):
                raise ValueError(f'{name}: scored dimension needs evidence')
            if level < 4 and not nonempty(item.get('reason')):
                raise ValueError(f'{name}: explain why next level is not met')
            known_weight += weight
            known_points += Decimal(weight) * level / 4
        else:
            if level is not None or not nonempty(item.get('reason')):
                raise ValueError(f'{name}: unknown/na needs null level and reason')
            if status == 'unknown':
                unknown_weight += weight
        if status != 'na':
            total_weight += weight
        trace.append({'dimension': name, 'weight': weight, **item})
    gates = record.get('gates', [])
    if not isinstance(gates, list) or (kind == 'question' and gates):
        raise ValueError('gates must be a list; question cannot use answer caps')
    cap = 100
    for gate in gates:
        if not isinstance(gate, dict) or gate.get('type') not in CAPS or not nonempty(gate.get('evidence')):
            raise ValueError('Each gate needs a supported type and concrete evidence')
        cap = min(cap, CAPS[gate['type']])
    result = {'rubric_version': '1.1', 'kind': kind, 'score': None, 'bounds': None,
              'coverage_percent': 0, 'cap': cap if gates else None, 'gates': gates,
              'trace': trace, 'interpretation': 'Weighted ordinal index; not objective utility or probability'}
    if total_weight == 0:
        result['status'] = 'not_applicable'
        return result
    scale = Decimal(100) / total_weight
    low = scale * known_points
    high = low + scale * unknown_weight
    result['coverage_percent'] = float(Decimal(known_weight) * scale)
    if unknown_weight:
        result['status'] = 'pending' if not known_weight else 'partial'
        result['bounds'] = [min(cap, int(low.to_integral_value(rounding=ROUND_FLOOR))),
                            min(cap, int(high.to_integral_value(rounding=ROUND_CEILING)))]
    else:
        result['status'] = 'scored'
        result['raw_score'] = float(low)
        result['score'] = min(cap, int(low.to_integral_value(rounding=ROUND_HALF_UP)))
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    result = evaluate(json.loads(args.input.read_text(encoding='utf-8-sig')))
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.write_text(rendered+'\n', encoding='utf-8')
    else:
        print(rendered)

if __name__ == '__main__':
    main()
